package com.example.myapplication.Activity;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Data.Post;
import com.example.myapplication.Interface.RetroClient;
import com.example.myapplication.R;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getName();
    TextView responseText;
    RetroClient retroClient;
    Button button1, button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        responseText = (TextView) findViewById(R.id.text);
        retroClient = RetroClient.getInstance(this).createBaseApi();

        System.out.println("asf asdf asdf sf ");

        button1.setText("GET");
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /**
                 GET List Resources
                 **/
                Call<ArrayList<Post>> call = retroClient.apiService.doGetListResources("posts");
                call.enqueue(new Callback<ArrayList<Post>>() {
                    @Override
                    public void onResponse(Call<ArrayList<Post>> call, Response<ArrayList<Post>> response) {
                        if(response.isSuccessful()){
                            ArrayList<Post> posts = response.body();
                            responseText.setText(posts.toString());
                        }
                        else{
                            Log.d(TAG, "onResponse: Error");
                        }
                    }

                    @Override
                    public void onFailure(Call<ArrayList<Post>> call, Throwable t) {
                        Log.d(TAG, "onFailure: " + t.toString());
                    }
                });
            }
        });

        button2.setText("POST");
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /**
                 Create new user
                 **/
                Post post = new Post("Fifth Post", "An", "this is my first post!!");
                Call<Post> call1 = retroClient.apiService.createPost(post);
                call1.enqueue(new Callback<Post>() {
                    @Override
                    public void onResponse(Call<Post> call, Response<Post> response) {

                        Log.d(TAG, "onResponse: " + response);
                        responseText.setText("message : " + response.message() + "\n" +
                                "body : " + response.body() + "\n" +
                                "isSuccessful : " + response.isSuccessful());
                    }

                    @Override
                    public void onFailure(Call<Post> call, Throwable t) {
                        call.cancel();
                    }
                });

            }
        });



    }
}